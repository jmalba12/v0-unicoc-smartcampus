# UNICOC SmartCampus

Este es un sistema de gestión académica avanzada para UNICOC, desarrollado con Next.js, Firebase y Genkit para IA.

## Cómo subir este proyecto a GitHub

Sigue estos comandos en tu terminal:

1. **Inicializar Git:**
   ```bash
   git init
   ```

2. **Añadir archivos:**
   ```bash
   git add .
   ```

3. **Primer commit:**
   ```bash
   git commit -m "Proyecto inicial UNICOC SmartCampus"
   ```

4. **Vincular repositorio remoto:**
   *Reemplaza `<URL>` con la URL de tu repositorio en GitHub.*
   ```bash
   git remote add origin <URL>
   git branch -M main
   ```

5. **Subir a GitHub:**
   ```bash
   git push -u origin main
   ```

## Estructura del Proyecto

- `/src/app`: Rutas y páginas de Next.js (Dashboard, Estudiantes, Finanzas, IA).
- `/src/ai`: Flujos de inteligencia artificial con Genkit.
- `/src/firebase`: Configuración y hooks de Firebase Firestore y Auth.
- `/components/ui`: Componentes visuales basados en ShadCN.

## Despliegue en Firebase

Este proyecto está configurado para **Firebase App Hosting**. 
Para desplegar, simplemente conecta tu repositorio de GitHub a Firebase desde el console de Firebase y se desplegará automáticamente con cada `push` a la rama principal.
