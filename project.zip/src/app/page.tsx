
import { redirect } from "next/navigation"

export default function RootPage() {
  // Redirigimos explícitamente para evitar conflictos con grupos de rutas
  // Aunque (dashboard)/page.tsx mapea a "/", forzamos la carga inicial
  // si el sistema de archivos de Next.js encuentra una colisión.
  return redirect("/ai-advisor");
}
