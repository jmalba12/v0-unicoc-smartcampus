
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { GraduationCap, Users, BookOpen, CreditCard, TrendingUp, AlertCircle, CheckCircle2, Clock, BrainCircuit } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function DashboardPage() {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-headline font-bold tracking-tight">System Overview</h1>
        <p className="text-muted-foreground">Welcome back, Admin. Here is what is happening across UNICOC today.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Active Students", value: "2,482", sub: "+12% from last term", icon: Users, color: "text-blue-500" },
          { label: "Faculty Members", value: "156", sub: "98.2% attendance", icon: GraduationCap, color: "text-emerald-500" },
          { label: "Current Revenue", value: "$1.2M", sub: "85% targets met", icon: CreditCard, color: "text-indigo-500" },
          { label: "Active Courses", value: "324", sub: "Fall 2024 Semester", icon: BookOpen, color: "text-orange-500" },
        ].map((stat, i) => (
          <Card key={i} className="border-border/40 bg-card/50 hover:bg-card/80 transition-colors shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">{stat.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-7">
        <Card className="md:col-span-4 border-border/40 shadow-xl overflow-hidden group">
          <CardHeader className="flex flex-row items-center justify-between bg-secondary/20 border-b border-border/20">
            <div>
              <CardTitle>Academic Performance</CardTitle>
              <CardDescription>Average GPA trends across faculties</CardDescription>
            </div>
            <TrendingUp className="text-primary size-5" />
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              {[
                { name: "Faculty of Dentistry", gpa: 4.2, progress: 84 },
                { name: "Faculty of Law", gpa: 3.8, progress: 76 },
                { name: "Faculty of Engineering", gpa: 4.5, progress: 90 },
                { name: "Faculty of Arts", gpa: 4.1, progress: 82 },
              ].map((faculty, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{faculty.name}</span>
                    <span className="font-bold text-primary">{faculty.gpa} / 5.0</span>
                  </div>
                  <Progress value={faculty.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-3 border-border/40 shadow-xl">
          <CardHeader>
            <CardTitle>System Activity</CardTitle>
            <CardDescription>Recent logs and audit trails</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {[
                { user: "System", action: "Automatic Backup", time: "2 min ago", icon: CheckCircle2, status: "success" },
                { user: "Admin", action: "Updated Grading Policy", time: "1 hour ago", icon: AlertCircle, status: "warning" },
                { user: "Finance", action: "Invoiced Semester B", time: "3 hours ago", icon: Clock, status: "pending" },
                { user: "Teacher", action: "Uploaded Calculus Final", time: "5 hours ago", icon: CheckCircle2, status: "success" },
              ].map((log, i) => (
                <div key={i} className="flex gap-4">
                  <div className={`mt-1 flex-shrink-0 size-8 rounded-full flex items-center justify-center bg-secondary`}>
                    <log.icon className={`size-4 ${log.status === 'success' ? 'text-emerald-500' : log.status === 'warning' ? 'text-amber-500' : 'text-blue-500'}`} />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-semibold">{log.action}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{log.user}</span>
                      <span className="size-1 rounded-full bg-muted-foreground/30"></span>
                      <span className="text-xs text-muted-foreground">{log.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
         <Card className="border-border/40 shadow-xl bg-gradient-to-br from-card to-secondary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BrainCircuit className="size-5 text-primary" />
              AI Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Based on current semester grades, we predict a 15% increase in engineering graduation rates.
            </p>
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
              Recommendation: Add peer tutoring for Calculus II
            </Badge>
          </CardContent>
        </Card>

        <Card className="border-border/40 shadow-xl">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Upcoming Deadlines</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-l-4 border-destructive pl-4 space-y-1">
              <p className="text-sm font-bold">Mid-Term Grade Submission</p>
              <p className="text-xs text-muted-foreground">Closes in 2 days</p>
            </div>
            <div className="border-l-4 border-amber-500 pl-4 space-y-1">
              <p className="text-sm font-bold">Financial Aid Review</p>
              <p className="text-xs text-muted-foreground">Scheduled for Friday</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 shadow-xl">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Server Health</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="flex items-center justify-between mb-2">
               <span className="text-sm">Response Time</span>
               <span className="text-sm font-bold text-emerald-500">24ms</span>
             </div>
             <Progress value={98} className="h-1 mb-4" />
             <div className="flex items-center justify-between">
               <span className="text-sm">Storage Usage</span>
               <span className="text-sm font-bold">1.2 TB / 5 TB</span>
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
