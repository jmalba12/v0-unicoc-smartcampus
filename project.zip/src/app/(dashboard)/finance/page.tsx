import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { 
  CreditCard, 
  Download, 
  Receipt, 
  Wallet, 
  ArrowUpRight, 
  FileText,
  CheckCircle2,
  Clock
} from "lucide-react"

const transactions = [
  { id: "INV-8821", student: "Valentina Gomez", concept: "Tuition Fall 2024", amount: 4500, date: "Oct 12, 2024", status: "Paid" },
  { id: "INV-8822", student: "Mateo Silva", concept: "Late Enrollment Fee", amount: 150, date: "Oct 15, 2024", status: "Pending" },
  { id: "INV-8823", student: "Sofia Castro", concept: "Library Overdue", amount: 25, date: "Oct 16, 2024", status: "Paid" },
  { id: "INV-8824", student: "Andrés Moreno", concept: "Lab Materials", amount: 300, date: "Oct 18, 2024", status: "Cancelled" },
]

export default function FinancePage() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-headline font-bold">Financial Center</h1>
        <p className="text-muted-foreground">Monitor institutional revenue, scholarship distribution, and pending accounts.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="bg-primary text-primary-foreground border-none shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-20">
            <Wallet className="size-24 rotate-12" />
          </div>
          <CardHeader>
            <CardTitle className="text-sm font-medium uppercase tracking-widest opacity-80">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">$2,845,210.00</div>
            <div className="flex items-center gap-2 mt-2 text-sm opacity-80">
              <ArrowUpRight className="size-4" />
              <span>+4.5% vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Scholarships Awarded</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$420,000</div>
            <div className="flex items-center gap-2 mt-2 text-sm text-emerald-500">
              <CheckCircle2 className="size-4" />
              <span>84 students supported</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Outstanding Debt</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">$82,140</div>
            <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
              <Clock className="size-4" />
              <span>12 invoices overdue</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2 border-border/40 shadow-xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Transactions</CardTitle>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="size-4" />
              Export Report
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-secondary/10 hover:bg-transparent">
                  <TableHead className="font-bold">Reference</TableHead>
                  <TableHead className="font-bold">Student</TableHead>
                  <TableHead className="font-bold">Concept</TableHead>
                  <TableHead className="font-bold text-right">Amount</TableHead>
                  <TableHead className="font-bold text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((tx) => (
                  <TableRow key={tx.id} className="border-border/10 hover:bg-secondary/10 transition-colors">
                    <TableCell className="font-mono text-xs font-bold text-primary">{tx.id}</TableCell>
                    <TableCell className="font-medium">{tx.student}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{tx.concept}</TableCell>
                    <TableCell className="text-right font-bold">${tx.amount.toLocaleString()}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline" className={
                        tx.status === "Paid" ? "border-emerald-500/30 text-emerald-500 bg-emerald-500/5" :
                        tx.status === "Pending" ? "border-amber-500/30 text-amber-500 bg-amber-500/5" :
                        "border-muted text-muted bg-muted/5"
                      }>
                        {tx.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-border/40 shadow-xl">
          <CardHeader>
            <CardTitle>Invoicing Tools</CardTitle>
            <CardDescription>Automated billing operations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full justify-start gap-3 h-12 bg-secondary/50 hover:bg-secondary text-foreground border-none">
              <Receipt className="size-5 text-primary" />
              <div className="text-left">
                <p className="text-sm font-bold leading-none">Generate Bulk Invoices</p>
                <p className="text-xs text-muted-foreground mt-1">For Semester B 2024</p>
              </div>
            </Button>
            <Button className="w-full justify-start gap-3 h-12 bg-secondary/50 hover:bg-secondary text-foreground border-none">
              <FileText className="size-5 text-primary" />
              <div className="text-left">
                <p className="text-sm font-bold leading-none">Scholarship Audit</p>
                <p className="text-xs text-muted-foreground mt-1">Review allocation limits</p>
              </div>
            </Button>
            <div className="pt-6 mt-6 border-t border-border/20">
               <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Payment Methods Usage</h4>
               <div className="space-y-3">
                  {[
                    { name: "Credit/Debit", pct: 65 },
                    { name: "Bank Transfer", pct: 25 },
                    { name: "Scholarship Credit", pct: 10 },
                  ].map((m, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{m.name}</span>
                        <span>{m.pct}%</span>
                      </div>
                      <Progress value={m.pct} className="h-1.5" />
                    </div>
                  ))}
               </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
