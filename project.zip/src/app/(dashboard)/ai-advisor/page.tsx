"use client"

import { useState } from "react"
import { generateStudyRecommendations, type StudentStudyRecommendationsOutput } from "@/ai/flows/student-study-recommendations"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { BrainCircuit, Loader2, Sparkles, GraduationCap, ChevronRight, CheckCircle2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function AIAdvisorPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<StudentStudyRecommendationsOutput | null>(null)

  const [formData, setFormData] = useState({
    studentName: "Santiago Rodriguez",
    academicProgram: "Computer Engineering",
    currentGPA: 3.8,
    currentSemester: 5,
    courseGrades: [
      { courseName: "Calculus III", grade: 3.2 },
      { courseName: "Data Structures", grade: 4.5 },
      { courseName: "Physics II", grade: 3.0 },
    ],
    strengths: "Logical thinking, Programming",
    weaknesses: "Time management, Advanced Mathematics",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const output = await generateStudyRecommendations({
        ...formData,
        strengths: formData.strengths.split(',').map(s => s.trim()),
        weaknesses: formData.weaknesses.split(',').map(s => s.trim()),
      })
      setResult(output)
    } catch (error) {
      console.error("AI Generation failed:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-headline font-bold tracking-tight flex items-center gap-3">
          <BrainCircuit className="size-10 text-primary" />
          AI Academic Advisor
        </h1>
        <p className="text-muted-foreground text-lg">Leverage UNICOC intelligence to optimize student learning paths.</p>
      </div>

      <div className="grid gap-8 md:grid-cols-5">
        <Card className="md:col-span-2 border-border/40 shadow-xl">
          <CardHeader>
            <CardTitle>Student Profile</CardTitle>
            <CardDescription>Input student metrics for analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Student Name</Label>
                <Input 
                  id="name" 
                  value={formData.studentName} 
                  onChange={(e) => setFormData({...formData, studentName: e.target.value})} 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="gpa">Current GPA</Label>
                  <Input 
                    id="gpa" 
                    type="number" 
                    step="0.1" 
                    value={formData.currentGPA} 
                    onChange={(e) => setFormData({...formData, currentGPA: parseFloat(e.target.value)})} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="semester">Semester</Label>
                  <Input 
                    id="semester" 
                    type="number" 
                    value={formData.currentSemester} 
                    onChange={(e) => setFormData({...formData, currentSemester: parseInt(e.target.value)})} 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="program">Academic Program</Label>
                <Input 
                  id="program" 
                  value={formData.academicProgram} 
                  onChange={(e) => setFormData({...formData, academicProgram: e.target.value})} 
                />
              </div>
              <div className="space-y-2">
                <Label>Strengths (comma separated)</Label>
                <Textarea 
                  value={formData.strengths}
                  onChange={(e) => setFormData({...formData, strengths: e.target.value})}
                  placeholder="e.g. Logic, Writing..."
                />
              </div>
              <Button type="submit" className="w-full gap-2 group" disabled={loading}>
                {loading ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4 group-hover:scale-110 transition-transform" />}
                Generate Smart Recommendations
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="md:col-span-3 space-y-6">
          {!result && !loading && (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 bg-secondary/20 rounded-xl border-2 border-dashed border-border/40">
              <BrainCircuit className="size-16 text-muted-foreground mb-4 opacity-20" />
              <h3 className="text-xl font-headline font-bold mb-2">Ready to Analyze</h3>
              <p className="text-muted-foreground max-w-sm">
                Complete the student profile on the left to generate personalized academic insights powered by GenAI.
              </p>
            </div>
          )}

          {loading && (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-4">
              <Loader2 className="size-12 animate-spin text-primary" />
              <p className="text-lg font-medium animate-pulse">Consulting UNICOC Knowledge Base...</p>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
              <Card className="border-primary/20 bg-primary/5 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl font-headline flex items-center gap-2">
                    <CheckCircle2 className="text-emerald-500 size-6" />
                    Overall Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg leading-relaxed text-foreground/90">
                    {result.overallAssessment}
                  </p>
                  <div className="mt-6 p-4 bg-background/50 rounded-lg border border-border/40">
                    <p className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-1">GPA Projection</p>
                    <p className="text-xl font-bold text-primary">{result.gpaProjection}</p>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4">
                <h3 className="text-xl font-headline font-bold px-2">Areas for Improvement</h3>
                {result.areasForImprovement.map((area, i) => (
                  <Card key={i} className="border-border/40 hover:border-primary/40 transition-colors">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{area.area}</CardTitle>
                        <Badge variant="outline" className="border-primary/20 text-primary">{area.reason}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <p className="text-sm font-bold text-muted-foreground uppercase tracking-tight">Suggested Actions</p>
                        <ul className="list-disc list-inside text-sm space-y-1 text-foreground/80">
                          {area.suggestedActions.map((action, j) => (
                            <li key={j}>{action}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="pt-4 border-t border-border/20">
                         <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Recommended Resources</p>
                         <div className="flex flex-wrap gap-2">
                            {area.suggestedResources.map((res, k) => (
                              <Badge key={k} variant="secondary" className="text-[10px]">{res}</Badge>
                            ))}
                         </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="border-border/40">
                <CardHeader>
                  <CardTitle>Study Strategies</CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {result.studyRecommendations.map((rec, i) => (
                      <AccordionItem value={`item-${i}`} key={i}>
                        <AccordionTrigger className="text-sm text-left">Strategy #{i+1}: {rec.split(':')[0]}</AccordionTrigger>
                        <AccordionContent className="text-muted-foreground">
                          {rec}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
