import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, UserPlus, Filter, Download, MoreHorizontal, Mail, Phone } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const students = [
  { id: "2024-001", name: "Valentina Gomez", program: "Dentistry", semester: 4, gpa: 4.8, status: "Active" },
  { id: "2024-002", name: "Mateo Silva", program: "Law", semester: 2, gpa: 3.9, status: "Probation" },
  { id: "2024-003", name: "Sofia Castro", program: "Business", semester: 8, gpa: 4.2, status: "Active" },
  { id: "2024-004", name: "Andrés Moreno", program: "Engineering", semester: 6, gpa: 4.5, status: "Active" },
  { id: "2024-005", name: "Camila Ruiz", program: "Arts", semester: 1, gpa: 3.5, status: "Inactive" },
  { id: "2024-006", name: "Nicolas Herrera", program: "Dentistry", semester: 3, gpa: 4.1, status: "Active" },
]

export default function StudentsPage() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold">Student Registry</h1>
          <p className="text-muted-foreground">Manage centralized academic records for all enrolled students.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="size-4" />
            Export CSV
          </Button>
          <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
            <UserPlus className="size-4" />
            Add Student
          </Button>
        </div>
      </div>

      <Card className="border-border/40 shadow-xl overflow-hidden">
        <CardHeader className="bg-secondary/20 border-b border-border/20 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by name, ID, or program..." className="pl-9 h-9 border-none bg-background shadow-none focus-visible:ring-1 focus-visible:ring-primary" />
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground">
                <Filter className="size-4" />
                Advanced Filters
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-secondary/10">
              <TableRow className="hover:bg-transparent border-border/20">
                <TableHead className="w-[120px] font-bold">Student ID</TableHead>
                <TableHead className="font-bold">Full Name</TableHead>
                <TableHead className="font-bold">Academic Program</TableHead>
                <TableHead className="font-bold text-center">Semester</TableHead>
                <TableHead className="font-bold text-center">GPA</TableHead>
                <TableHead className="font-bold">Status</TableHead>
                <TableHead className="text-right font-bold pr-6">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow key={student.id} className="border-border/10 hover:bg-secondary/10 transition-colors group">
                  <TableCell className="font-mono text-xs text-primary font-bold">{student.id}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="size-8 rounded-full bg-secondary flex items-center justify-center font-bold text-xs uppercase">
                        {student.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="font-medium">{student.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>{student.program}</TableCell>
                  <TableCell className="text-center">{student.semester}°</TableCell>
                  <TableCell className="text-center">
                    <Badge variant={student.gpa >= 4.0 ? "default" : "secondary"} className={student.gpa >= 4.0 ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : ""}>
                      {student.gpa.toFixed(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      student.status === "Active" ? "border-emerald-500/30 text-emerald-500 bg-emerald-500/5" :
                      student.status === "Probation" ? "border-amber-500/30 text-amber-500 bg-amber-500/5" :
                      "border-red-500/30 text-red-500 bg-red-500/5"
                    }>
                      {student.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="icon" className="size-8">
                        <Mail className="size-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="size-8">
                        <Phone className="size-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem>View Academic History</DropdownMenuItem>
                          <DropdownMenuItem>Financial Record</DropdownMenuItem>
                          <DropdownMenuItem>Edit Profile</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">Suspend Access</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <p>Showing 1 to 6 of 2,482 students</p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" disabled>Previous</Button>
          <Button variant="outline" size="sm">Next</Button>
        </div>
      </div>
    </div>
  )
}
