import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/dashboard/app-sidebar"
import { Separator } from "@/components/ui/separator"
import { Bell, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="bg-background">
        <header className="flex h-16 shrink-0 items-center justify-between gap-2 border-b border-border/40 px-6 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <div className="relative w-72 group-data-[collapsible=icon]:hidden md:block hidden">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search campus records..."
                className="w-full bg-secondary/50 pl-9 border-none focus-visible:ring-1 focus-visible:ring-primary h-9"
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell className="size-5" />
              <span className="absolute top-2 right-2 size-2 bg-primary rounded-full border-2 border-background"></span>
            </Button>
            <div className="h-8 w-[1px] bg-border/40 mx-2"></div>
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold leading-none">UNICOC Central</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mt-1">SmartCampus v2.5</p>
            </div>
          </div>
        </header>
        <main className="flex-1 p-6 overflow-x-hidden">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
