'use server';
/**
 * @fileOverview This file implements a Genkit flow for providing personalized study recommendations to students.
 *
 * - generateStudyRecommendations - A function that analyzes student academic performance to generate study recommendations.
 * - StudentStudyRecommendationsInput - The input type for the generateStudyRecommendations function.
 * - StudentStudyRecommendationsOutput - The return type for the generateStudyRecommendations function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const StudentStudyRecommendationsInputSchema = z.object({
  studentName: z.string().describe("The student's name."),
  currentGPA: z.number().describe("The student's current Grade Point Average (on a 0.0 to 5.0 scale)."),
  academicProgram: z.string().describe("The student's academic program (e.g., 'Computer Science', 'Business Administration')."),
  currentSemester: z.number().describe("The student's current academic semester."),
  courseGrades: z.array(
    z.object({
      courseName: z.string().describe("The name of the course (e.g., 'Calculus I', 'Data Structures')."),
      grade: z.number().describe("The student's grade in the course (on a 0.0 to 5.0 scale)."),
    })
  ).describe("A list of the student's grades in various courses."),
  strengths: z.array(z.string()).optional().describe("Optional: Areas where the student typically excels."),
  weaknesses: z.array(z.string()).optional().describe("Optional: Areas where the student typically struggles."),
});
export type StudentStudyRecommendationsInput = z.infer<typeof StudentStudyRecommendationsInputSchema>;

const StudentStudyRecommendationsOutputSchema = z.object({
  overallAssessment: z.string().describe("A brief overall assessment of the student's academic performance based on the provided data."),
  studyRecommendations: z.array(
    z.string()
  ).describe("A list of personalized study strategies and general tips for the student to optimize their learning."),
  areasForImprovement: z.array(
    z.object({
      area: z.string().describe("A specific subject, course, or academic area identified for improvement."),
      reason: z.string().describe("The reason this area was identified for improvement (e.g., low grades, foundational concept, prerequisite for future courses)."),
      suggestedActions: z.array(z.string()).describe("Specific, actionable steps the student can take to improve in this area."),
      suggestedResources: z.array(z.string()).describe("Recommended resources (e.g., specific textbooks, online courses, tutoring services, peer study groups) for this area."),
    })
  ).describe("A list of specific academic areas where the student can improve, including detailed reasons, suggested actions, and recommended resources."),
  gpaProjection: z.string().describe("A qualitative projection of the student's potential GPA based on their current performance and the successful implementation of the provided recommendations."),
});
export type StudentStudyRecommendationsOutput = z.infer<typeof StudentStudyRecommendationsOutputSchema>;

export async function generateStudyRecommendations(input: StudentStudyRecommendationsInput): Promise<StudentStudyRecommendationsOutput> {
  return studentStudyRecommendationsFlow(input);
}

const studentStudyRecommendationsPrompt = ai.definePrompt({
  name: 'studentStudyRecommendationsPrompt',
  input: { schema: StudentStudyRecommendationsInputSchema },
  output: { schema: StudentStudyRecommendationsOutputSchema },
  config: {
    safetySettings: [
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
    ],
  },
  prompt: `You are an expert academic advisor at UNICOC SmartCampus. Your goal is to help students optimize their learning strategy and enhance their academic success by providing personalized study recommendations and identifying areas for improvement.

Analyze the following academic information for the student:

Student Name: {{{studentName}}}
Academic Program: {{{academicProgram}}}
Current Semester: {{{currentSemester}}}
Current GPA: {{{currentGPA}}}

Course Grades:
{{#each courseGrades}}
- Course: {{{courseName}}}, Grade: {{{grade}}}
{{/each}}

{{#if strengths}}
Student Strengths:
{{#each strengths}}
- {{{this}}}
{{/each}}
{{/if}}

{{#if weaknesses}}
Student Weaknesses:
{{#each weaknesses}}
- {{{this}}}
{{/each}}
{{/if}}

Based on this data, provide a comprehensive overall assessment of the student's academic performance. Then, generate personalized study recommendations, clearly identify areas for improvement with specific reasons, suggested actions, and relevant resources. Finally, give a qualitative GPA projection based on their current performance and adherence to your advice.

Ensure your recommendations are actionable, specific, and tailored to the student's profile. Use a supportive and encouraging tone.
`,
});

const studentStudyRecommendationsFlow = ai.defineFlow(
  {
    name: 'studentStudyRecommendationsFlow',
    inputSchema: StudentStudyRecommendationsInputSchema,
    outputSchema: StudentStudyRecommendationsOutputSchema,
  },
  async (input) => {
    const { output } = await studentStudyRecommendationsPrompt(input);
    return output!;
  }
);
