import { config } from 'dotenv';
config();

import '@/ai/flows/student-study-recommendations.ts';