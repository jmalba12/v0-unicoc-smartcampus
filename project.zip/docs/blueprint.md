# **App Name**: UNICOC SmartCampus

## Core Features:

- Role-Based Academic Management: Comprehensive CRUD systems for students, teachers, and faculty with strictly enforced role-based access control (RBAC).
- Firestore Unified Database: Scalable NoSQL architecture storing institutional data across collections like grades, payments, schedules, and notifications.
- AI Academic Advisor: An AI-powered tool that analyzes student performance and grades to generate personalized study recommendations and GPA projections.
- Financial Tracking & Billing: Automated payment registration, history tracking, and generation of digital PDF invoices for tuition and library fees.
- Secure JWT Authentication: Identity management via Firebase Authentication combined with custom JWT tokens for secure, long-lived administrative sessions.
- Smart Conflict Scheduler: Logic-heavy scheduling system that prevents double-booking of classrooms or professor time slots during course assignments.
- Real-time Notification Hub: Push and in-app alert system for grade updates, financial deadlines, and campus-wide institutional announcements.

## Style Guidelines:

- Primary color: Deep Institutional Navy (#1A365D), reflecting authority and academic excellence.
- Background color: Deep Charcoal Slate (#0F172A), providing a focused, high-end dark interface for administrative productivity.
- Accent color: Cyber Cobalt (#3B82F6), used for active links, buttons, and high-priority dashboard elements.
- Headline font: 'Space Grotesk' (sans-serif) for a modern, computerized technical feel. Body font: 'Inter' (sans-serif) for maximum legibility in dense data tables.
- Modular bento-grid layout for the dashboard to manage multiple academic modules efficiently on a single screen.
- Sharp, 2px stroke weight linear icons to maintain a professional 'Enterprise' look and feel across the management portal.
- Minimal state transitions and subtle fade-ins when switching between dashboard modules to maintain a fast, robust user experience.